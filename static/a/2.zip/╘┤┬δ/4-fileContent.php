<?php
/*
文件内容相关操作
*/
$filename='./1.txt';
//fopen():打开指定文件，以指定的方式来打开
$handle=fopen($filename,'r');
// var_dump($handle);
//fread():读取文件内容
// $res=fread($handle,3);
// echo $res,'<br/>';
// $res=fread($handle,3);
// echo $res;
// $res=fread($handle,filesize($filename));
// echo $res;
// echo ftell($handle),'<br/>';
// fread($handle,3);
// echo ftell($handle),'<br/>';
fread($handle,filesize($filename));
echo ftell($handle);
echo '<hr/>';
var_dump(fread($handle,21));
//fseek($handle,$num):重置指针
echo '<hr/>';
fseek($handle,0);
var_dump(fread($handle,21));
//fclose($handle):关闭文件句柄
fclose($handle);
var_dump(fread($handle,21));
