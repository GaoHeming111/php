<?php
require_once 'file.func.php';
$filename=$_GET['filename'];
down_file1($filename);
