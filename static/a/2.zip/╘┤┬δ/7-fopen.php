<?php
//如果文件不存在会创建，
//如果文件存在，会先将文件内容截断为0，接着在开始写入
$filename="./1.txt";
$filename="2.txt";
$handle=fopen($filename,'ab+');
// fputs($handle,'this is a test'.PHP_EOL);
// fputs($handle,'hello world');
fwrite($handle,PHP_EOL.'hello king');
fclose($handle);
